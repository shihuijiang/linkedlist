import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class ReadFile {
	protected void terminate() throws IOException{
		System.out.println("The input has more right brackets ");
		System.exit(0);
	}//exit and print out the message
	
	//read the txt file and save the right brackets in the array stack
	//match the right brackets and to the left brackets and pop out of the stack
	public ReadFile(String file) throws FileNotFoundException{
		FileInputStream fstream=null;
		try {
			fstream = new FileInputStream(file);
			DynamicArrayStack<Character> arrayStack=new DynamicArrayStack<Character>();
			
			int p;
			while ((p = fstream.read()) != -1) {
				char pare=(char)(p) ;
				
				//save left brackets in the stack
				if(pare=='{'||pare=='['||pare=='('){
					arrayStack.push(pare);
					System.out.print(arrayStack.top());
				}
				
				//right brackets
					if(pare=='}'){	
						//if the stack is empty, exit
						if(arrayStack.isEmpty()){
							fstream.close();
							terminate();
						}
						//if the stack has no matching left brackets, exit
						if(arrayStack.top()!='{'){
							fstream.close();
							terminate();
						}
						//if there is matching brackets
						arrayStack.pop();
						System.out.print(pare);
					

					}
					if(pare==']'){
						if(arrayStack.isEmpty()){
							fstream.close();
							terminate();
						}
						if(arrayStack.top()!='['){
							fstream.close();
							terminate();
						}
						arrayStack.pop();
						System.out.print(pare);
				

					}
					if(pare==')'){
						if(arrayStack.isEmpty()){
							fstream.close();
							terminate();
						}
						if(arrayStack.top()!='('){
							fstream.close();
							terminate();
						}
						arrayStack.pop();
						System.out.print(pare);
				
					}
					
			}
			//when the stack is not empty
			if(!arrayStack.isEmpty()){
					fstream.close();
					System.out.println("The input has more left brackets");
					System.exit(0);
			}
			
		}catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				
				if (fstream != null)
					fstream.close();//file close
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}
	
	
}
	