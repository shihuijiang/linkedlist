import java.util.EmptyStackException;

public class DynamicArrayStack<AnyType> implements Stack<AnyType>
{
  public static final int DEFAULT_CAPACITY = 1024;
  AnyType[] data;
  int topOfStack;

  public DynamicArrayStack() { this(DEFAULT_CAPACITY); }
//creates a new empty stack with default capacity.
  public DynamicArrayStack(int capacity)
  {
    topOfStack = -1;
    data = (AnyType[]) new Object[capacity];
  }
//returns the size of the stack.
  public int size()
  {
    if(topOfStack==-1)
    return 0;
    else return topOfStack+1;
  }
//returns true if the stack is empty.
  public boolean isEmpty()
  {    
    if (size()==0) return true;
    else return false;
    
  }
//add a value on top of the stack,
//if the stack is full, extend the length of the stack.
  public void push(AnyType newValue){
    if (size()==data.length) {
        resize(data.length*2);    
        }
    topOfStack++;
    data[topOfStack]=newValue;
  
  }
//returns the value on top of the stack

  public AnyType top()
  {    
    if(isEmpty()) throw new EmptyStackException();
    return data[topOfStack];
  }
//returns the value on top of the stack and removes it 
  public AnyType pop()
  {
    if(isEmpty()) throw new EmptyStackException();
    
    AnyType oldValue=data[topOfStack];
   
    data[topOfStack]=null; 
    topOfStack--;
    return oldValue;

  }
//resize of the stack




  protected void resize(int newCapacity){
    AnyType[] temp=(AnyType[]) new Object[newCapacity];
            for(int i=0;i<size();i++){
                temp[i]=data[i];
            }
    data=temp;
    }
}